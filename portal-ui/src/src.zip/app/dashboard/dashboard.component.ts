import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  config = {
    "first_name_len" : 20,
    "last_name_len" : 15
  };
  firstName = "Sourabh";
  lastName : string;

  constructor() { }

  ngOnInit() {
  }

}
